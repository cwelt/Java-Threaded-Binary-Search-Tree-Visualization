Inorder to run this application,  
all you need to do is exctract the files, 
open the folder "WiredBST" and run the file "runApplication.bat"
check out the input example file if you want to input scripts of your own,
detailed format syntax is found in the word file. 